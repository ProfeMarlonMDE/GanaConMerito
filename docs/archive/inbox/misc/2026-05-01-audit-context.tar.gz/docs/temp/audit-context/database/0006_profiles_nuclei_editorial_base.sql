-- 0006_profiles_nuclei_editorial_base.sql
-- Base para segmentación por perfil profesional + núcleos temáticos + estado editorial extendido

begin;

create table if not exists public.professional_profiles (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  description text,
  area text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.thematic_nuclei (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  description text,
  area text,
  subarea text,
  is_universal boolean not null default false,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.profile_thematic_nuclei (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.professional_profiles(id) on delete cascade,
  nucleus_id uuid not null references public.thematic_nuclei(id) on delete cascade,
  is_enabled boolean not null default true,
  priority_weight integer not null default 100,
  created_at timestamptz not null default now(),
  unique (profile_id, nucleus_id)
);

alter table public.profiles
  add column if not exists professional_profile_id uuid references public.professional_profiles(id);

alter table public.item_bank
  add column if not exists thematic_nucleus_id uuid references public.thematic_nuclei(id),
  add column if not exists status text not null default 'draft' check (
    status in ('draft', 'review', 'published', 'archived')
  ),
  add column if not exists is_active boolean not null default true,
  add column if not exists source_type text not null default 'manual' check (
    source_type in ('manual', 'markdown', 'import', 'seed')
  ),
  add column if not exists source_path text;

-- Backfill inicial para no romper selección existente
update public.item_bank
set status = 'published'
where is_published = true
  and status = 'draft';

create index if not exists idx_professional_profiles_code
  on public.professional_profiles(code);
create index if not exists idx_professional_profiles_active
  on public.professional_profiles(is_active);

create index if not exists idx_thematic_nuclei_code
  on public.thematic_nuclei(code);
create index if not exists idx_thematic_nuclei_active
  on public.thematic_nuclei(is_active);
create index if not exists idx_thematic_nuclei_universal
  on public.thematic_nuclei(is_universal);

create index if not exists idx_profile_thematic_nuclei_profile_id
  on public.profile_thematic_nuclei(profile_id);
create index if not exists idx_profile_thematic_nuclei_nucleus_id
  on public.profile_thematic_nuclei(nucleus_id);
create index if not exists idx_profile_thematic_nuclei_enabled
  on public.profile_thematic_nuclei(is_enabled);

create index if not exists idx_profiles_professional_profile_id
  on public.profiles(professional_profile_id);

create index if not exists idx_item_bank_thematic_nucleus_id
  on public.item_bank(thematic_nucleus_id);
create index if not exists idx_item_bank_status
  on public.item_bank(status);
create index if not exists idx_item_bank_is_active
  on public.item_bank(is_active);
create index if not exists idx_item_bank_status_active
  on public.item_bank(status, is_active);

create trigger trg_professional_profiles_updated_at
before update on public.professional_profiles
for each row
execute function public.set_updated_at();

create trigger trg_thematic_nuclei_updated_at
before update on public.thematic_nuclei
for each row
execute function public.set_updated_at();

alter table public.professional_profiles enable row level security;
alter table public.thematic_nuclei enable row level security;
alter table public.profile_thematic_nuclei enable row level security;

-- Lectura autenticada mínima; endurecer luego para admin/editor si hace falta.
create policy professional_profiles_select_authenticated
on public.professional_profiles
for select
using (auth.uid() is not null);

create policy thematic_nuclei_select_authenticated
on public.thematic_nuclei
for select
using (auth.uid() is not null);

create policy profile_thematic_nuclei_select_authenticated
on public.profile_thematic_nuclei
for select
using (auth.uid() is not null);

commit;
