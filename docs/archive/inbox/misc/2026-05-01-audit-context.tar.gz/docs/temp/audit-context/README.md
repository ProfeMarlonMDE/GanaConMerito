# Audit Context — GanaConMerito

Carpeta temporal para dar contexto a una auditoría externa sobre segmentación por perfil profesional y módulo editorial/admin.

## Punto de entrada recomendado
1. `audit-brief-editorial-segmentation.md`
2. `architecture/editorial-admin-implementation-plan.md`
3. `database/0006_profiles_nuclei_editorial_base.sql`

## Contenido

### Brief de auditoría
- `audit-brief-editorial-segmentation.md`

### Arquitectura
- `architecture/editorial-admin-implementation-plan.md`
- `architecture/editorial-module-plan.md`
- `architecture/overview.md`

### Base de datos
- `database/schema.md`
- `database/0001_init_mvp.sql`
- `database/0006_profiles_nuclei_editorial_base.sql`

### Lógica adaptativa
- `domain/select-next-item.ts`

### API
- `api/contracts.md`

## Objetivo de esta carpeta
Permitir que otra IA o auditor humano tenga acceso rápido a los archivos mínimos necesarios para evaluar:
- coherencia de negocio
- coherencia técnica
- riesgos
- ajustes recomendados
- orden de implementación
- validez de la migración 0006

## Nota
Estos archivos son copias temporales de contexto. La fuente real sigue estando en sus ubicaciones originales del repo.
